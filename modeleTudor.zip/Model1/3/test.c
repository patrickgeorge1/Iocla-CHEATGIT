#include <stdio.h>

void direct(const char *s, unsigned int perturb);
size_t obvious(unsigned int a, unsigned int b);
void crypto(const unsigned char *in, unsigned char *out, size_t len, const unsigned char *key, size_t klen);

int main(void)
{
	unsigned char in[128] = "no country for old men";
	unsigned char out[128] = {0};
	unsigned char k[16] = "sibling1";

	direct("bad", 0x61232);
	int rez = obvious(0xB3, 5001);
    printf("%d\n", rez);
	crypto(in, out, 21, k, 11);
	crypto(out, out, 21, k, 11);
	printf("%s\n", out);

	return 0;
}
