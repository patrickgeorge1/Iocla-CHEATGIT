# Teme

Toate temele au fost puse pe git **dupa deadline**.

## Tema 1 - evaluare de expresie in forma poloneza postfixata

- titlul explica tot

## Tema 2 - (de)criptari bazate pe xor

- diversi (6) algoritmi simpli de criptare, bazati pe operatia `xor` byte cu byte intre o cheie si un string

## Tema 3 - optimizari

- pornind de la un binar dat, se va optimiza setul de functii `mystery` o data pentru un timp de executie cat mai mic si apoi pentru o dimensiune minima
