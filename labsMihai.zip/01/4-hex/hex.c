#include<stdio.h>

int main()
{
    // TODO declare a char[] variable that stores the string
    char string[] = "\x48\x45\x58\x20\x52\x6f\x63\x6b\x73\x21\x0a";
    
    // TODO print the char[] variable
    printf("%s", string);

    return 0;
}
