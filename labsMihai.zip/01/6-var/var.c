#include <stdio.h>

int main(void)
{
    short a = 20000;
    short b = 14000;

    short c = a + b;
    unsigned short d = 3 * a + b;
    short e = a << 1;

    // TODO - print variables c, d, e

    printf("c: %d\n", c);
    printf("d: %d\n", d);
    printf("e: %d\n", e);


    // explicatie: pe short incap maxim 2^15 - 1, adica 32766
    // rezultatul este 34000 care nu incape, deci un bit se pierde si devine bit de semn,
    // de asta c are valoare negativa
    // acelasi lucru se intampla si la d, dar se pierde cel mai semnificativ bit
    // la e, se shifteaza la stanga si primul bit(cel mai semnificativ) trece 
    // la semn, astfel numarul devine negativ 
    return 0;
}
