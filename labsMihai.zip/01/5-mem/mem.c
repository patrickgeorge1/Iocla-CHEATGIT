#include <stdio.h>

void showBytesSigned(void* address, size_t size) {
    char *p;
    
    p = (char *) address;

    for (size_t i = 0; i < size; i++)
        printf("0x%02x ", p[i]);
    
    printf("\n");
}

void showBytesUnsigned(void* address, size_t size) {
     unsigned char *p;
    
    p = (unsigned char *) address;

    for (size_t i = 0; i < size; i++)
        printf("0x%02x ", p[i]);
    
    printf("\n");
}

int main(void)
{
    unsigned int a = 4127;
    int b = -27714;
    unsigned int c = 0x12345678;
    char d[] = {'I', 'O', 'C', 'L', 'A'};

    // TODO
    printf("a: ");
    showBytesUnsigned(&a, sizeof(a));
    
    printf("b: ");
    showBytesSigned(&b, sizeof(b));
    
    printf("c: ");
    showBytesUnsigned(&c, sizeof(c));
    
    printf("d: ");
    showBytesSigned(&d, sizeof(d));
    
    return 0;
}
