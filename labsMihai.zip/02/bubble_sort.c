#include <stdio.h>

int main() {
    int v[] = {5, 0, 1, 400, 2}, n = 5, tmp, i, j;
    
    i = 0;

loop:
    j = i + 1;

innerLoop:
    if(v[i] > v[j]) {
        tmp = v[i];
        v[i] = v[j];
        v[j] = tmp;
    }

    ++j;
    if(j < n) {
        goto innerLoop;
    }

    ++i;
    if(i < n - 1) {
        goto loop;
    }

    for(int i = 0; i < n; ++i) {
        printf("%d ", v[i]);
    }

    printf("\n");
    return 0;
}