#include <stdio.h>

int main() {
    int v[] = {0, 5, 10, 15, 50, 60, 70}, n = 6, target = 15;

    int l = 0, r = n, mid = 0;

    printf("v: ");

    for(int i = 0; i < n; ++i) {
        printf("%d ", v[i]);
    }

    printf("\ntarget: %d\n", target);

binarySearchLoop:
    mid = (l + r)/2;

    if(target == v[mid]) {
        printf("found at %d\n", mid);
        goto loopExit;
    }

    if(target > v[mid]) {
        l = mid + 1;
    } 

    if(target < v[mid]) {
        r = mid - 1;
    }

    if(l < r) {
        goto binarySearchLoop;
    }

    printf("not found..\n");

loopExit:
    return 0;
}