#include <stdio.h>
#include <limits.h>

int main() {
    int v[] = {5, 0, 1, 400, 2}, max = INT_MIN, n = 5;
    
    printf("v: ");

    for(int i = 0; i < n; ++i) {
        printf("%d ", v[i]);
    }
    
    printf("\n");

    int i = 0;

loopLabel:
    if(v[i] > max) {
        max = v[i];
    }

    ++i;

    if(i < n) {
        goto loopLabel;
    }

    printf("max: %d\n", max);   

    return 0;
}