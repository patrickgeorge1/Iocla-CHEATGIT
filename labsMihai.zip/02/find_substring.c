#include <stdio.h>
#include <string.h>

int main() {
    char haystack[] = "abbca";
    char needle[] = "bca";

    printf("haystack: %s\nneedle: %s\n", haystack, needle);

    int hlen = strlen(haystack), nlen = strlen(needle);
    int i = 0, diff, j;

loop:
    diff = 0;

    j = i;

innerLoop:
    if(haystack[j] != needle[j-i]) {
        diff = 1;
    }

    ++j;
    if(j < i + nlen) {
        goto innerLoop;
    }

    if(diff == 0) {
        printf("found at pos %d\n", i);
        goto exitLoop;
    }

    ++i;
    if(i < hlen-nlen +1) {
        goto loop;
    }

    // for(int i = 0; i < hlen-nlen + 1; ++i) {
    //     int diff = 0;

    //     for(int j = i; j < i + nlen; ++j) {

    //         if(haystack[j] != needle[j-i]) {
    //             diff = 1;
    //         }
    //     }

    //     if(diff == 0) {
    //         printf("found at pos %d\n", i);
    //         return 0;
    //     }
    // }

    printf("not found..\n");

exitLoop:
    return 0;
    
}