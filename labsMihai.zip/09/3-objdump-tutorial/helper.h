int helper_function(float a, float b) {
	return a + b;
}
