int outsider_var = 3;

char outsider_function(){
    return 'A';
}

char undefined_function(){
    return 'B';
}